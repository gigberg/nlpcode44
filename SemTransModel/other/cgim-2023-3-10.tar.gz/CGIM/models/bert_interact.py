import logging
import pprint
import random
import fitlog
import numpy as np
import torch
import torch.nn as nn
from torch.nn import functional as F
from transformers import AdamW
from models.interactive_block import CycleGuidedInteractiveLearningModule
import utils.tools.tool
from utils.tools.manager import PretrainedModelManager
from utils.tools.recorder import Recoder
from utils.tools.tool import Batch
from tqdm import tqdm
import re
import os
from utils.evaluate import EvaluateTool
from utils.loader import DatasetTool
# CGIM和CI-ToD代码的区别
# 1）模型本体的代码由bert.py变成bert_interact.py, 模型配置文件变为KBRetriver_DC_INTERACTIVE.cfg（原先KBRetriver_DC_BERT.cfg）
# 2）模型原先继承两级base.py,变成直接继承自torch.nn.Module，并在模型中引入模型主体（models.interactive_block.py---CycleGuidedInteractiveLearningModule类)
# 3）从调用from_pretrain()下载预训练好的bert模型，到基于预训练模型输出层，自行设计模型结构
# 4）模型输入不同, kb+h,last,entities --> hb,h,q,last,entities
# bert.p中train_data结构为：[list of n dict_dialogue, every dialogue is a dict of 3key-value ]: constructed_concatenate_dialogue_info_string(kb+h), last_response, consistency
# bert_interact.py本代码中interact_train_data结构为：[list of n dict_dialogue, dialogue is dict of 5key-value]:  kb,history,query, last_response, consistency                
# 5）utils.tools中多了manager.py和recorder.py(都有在模型中被调用)


class CGIM(torch.nn.Module): # 基于预训练的bert模型的输出层，自行设计后续的CGIM模型网络结构，并训练
    def __init__(self, args, inputs):
        super().__init__()
        self.args = args
        self.DatasetTool = DatasetTool
        self.EvaluateTool = EvaluateTool
        _, _, _, entities = inputs
        # Pretrained Model Preparation by manager.py
        manager = PretrainedModelManager(self.args)
        self.bert = manager.bert
        self.tokenizer = manager.tokenizer
        special_tokens_dict = {'additional_special_tokens': manager.special_tokens + entities}
        self.tokenizer.add_special_tokens(special_tokens_dict)
        self.bert.resize_token_embeddings(len(self.tokenizer))
        self.get_info = manager.get_info
        #--- Model Definition ---# 在预训练模型的输出层基础上，再添加深度学习网络来训练自己的模型
        # 在hungging下载好的bert-base-uncased文件bert_config.json中配置了隐藏层大小"hidden_size": 768
        self.hidden_size = args.train.hidden_size # hidden_size=768 同bert.py
        self.pretrain_size = args.train.pretrain_size # pretrain_size=768 同bert.py 
        self.models = nn.ModuleList(
            [CycleGuidedInteractiveLearningModule(args).to(self.device) for _ in range(args.train.layer_num)]) # layer_num=2
        # hidden_q, hidden_kb, hidden_h = CycleGuidedInteractiveLearningModule(hidden_state_q, hidden_state_kb, hidden_state_h)
        self.w_hi = nn.Linear(self.hidden_size * 3, 2) # (768*3, 2)self.hidden_size=768 同bert.py
        self.w_qi = nn.Linear(self.hidden_size * 3, 2)
        self.w_kbi = nn.Linear(self.hidden_size * 3, 2)
        self.w_h = nn.Linear(self.pretrain_size, self.hidden_size) # (768, 768)
        self.w_q = nn.Linear(self.pretrain_size, self.hidden_size)
        self.w_kb = nn.Linear(self.pretrain_size, self.hidden_size)
        self.criterion = nn.BCELoss()
        self.recoder = Recoder("out/", self.args, 1)

    @property
    def device(self):
        if self.args.train.gpu:
            return torch.device('cuda')
        else:
            return torch.device('cpu')

    def set_optimizer(self):
        all_params = set(self.parameters())
        params = [{"params": list(all_params), "lr": self.args.lr.bert}]
        self.optimizer = AdamW(params) # AdamW “自适应学习率” 优化算法

    def forward(self, batch):
        # Get KB Encoded Vector
        # tokenize后的数据结构tokenized: <class 'dict'> {input_ids: [8[512]] , token_type_ids: [8[512]], attention_mask: [8[512]]}
        kb_token_ids, kb_type_ids, kb_mask_ids = self.get_info(batch, 'knowledge_base') # 每条数据512个token
        h_kb, utt_kb = self.bert(input_ids=kb_token_ids, token_type_ids=kb_type_ids, attention_mask=kb_mask_ids)
        # 在模型配置文件中KBRetriver_DC_INTERACTIVE.cfg设置batchsize大小：batch = 8
        # 在hungging下载好的bert-base-uncased文件tokenizer_config.json中配置了tokennized向量大小："model_max_length": 512
        # 在hungging下载好的bert-base-uncased文件bert_config.json中配置了隐藏层大小"hidden_size": 768,
        # h_kb[8*512*768]: last_hidden_state对应的是所有其他的输入字的最后输出: (torch.FloatTensor of shape (batch_size_8, sequence_length_512, hidden_size_768))
        # utt_kb[8,768]: pooler_output对应的是 [CLS] 的输出: (torch.FloatTensor of shape (batch_size, hidden_size))
        # (pooler_output 是序列的最后一层的隐藏状态的第一个token（classification token), 经过一个线性层和 Tanh 激活函数进一步处理后得到的)
        # Get Query Encoded Vector
        q_token_ids, q_type_ids, q_mask_ids = self.get_info(batch, 'query') # 每条数据25个token， q_*_ids[8*25], h_q[8, 25, 768], utt_q[8, 768]
        h_q, utt_q = self.bert(input_ids=q_token_ids, token_type_ids=q_type_ids, attention_mask=q_mask_ids)
        # Get History Encoded Vector
        h_token_ids, h_type_ids, h_mask_ids = self.get_info(batch, 'history') # 每条数据82个token，h_*_ids[8*82], h_h[8, 52, 768], utt_h[8, 768]
        h_h, utt_h = self.bert(input_ids=h_token_ids, token_type_ids=h_type_ids, attention_mask=h_mask_ids)

        # Get Hidden Interactive Encoded Vectors # # hidden[8, 3, 768]
        # 和bert中一样，没有用到h，只凭借utt_cls得到out_qi:self.w_qi(hidden_q...)
        hidden = torch.cat((utt_q.view(-1, 1, self.pretrain_size), # utt_*[8*768] --view--> [8, 1, 768]中间的维度主要用于指定cat方向
                            utt_h.view(-1, 1, self.pretrain_size), # the size -1 is inferred from other dimensions
                            utt_kb.view(-1, 1, self.pretrain_size)), dim=1) # dim=1, utt_*.view[8, 1, 768] --cat--> hidden[8, 3, 768]
        hidden_q = self.w_q(hidden) # # input: hidden[8, 3, 768] # 相当于联合训练？？
        hidden_h = self.w_h(hidden) # # model: self.w_*(768, 768)
        hidden_kb = self.w_kb(hidden) # # output: hidden_*[8, 3, 768]

        # Encoded by circle transformer layers # # hidden_state_* --Cycle--> hidden_*
        # hidden_q, hidden_kb, hidden_h = CycleGuidedInteractiveLearningModule(hidden_state_q, hidden_state_kb, hidden_state_h)
        for model in self.models: # CycleGuidedInteractiveLearningModule # layer_num=2
            hidden_q, hidden_kb, hidden_h = model(hidden_state_q=hidden_q, hidden_state_h=hidden_h,
                                                  hidden_state_kb=hidden_kb)
        # Linear decode layer # # hidden_* shape is still hidden_*[8, 3, 768]
        # 和bert中一样，没有用到h，只凭借utt_cls得到out_qi:self.w_qi(hidden_q...)
        out_qi = self.w_qi(hidden_q.view(-1, self.hidden_size * 3)) # # input: hidden_*[8, 3*768] 
        out_hi = self.w_hi(hidden_h.view(-1, self.hidden_size * 3)) # # model: self.w_*i(768*3, 2)
        out_kbi = self.w_kbi(hidden_kb.view(-1, self.hidden_size * 3)) # # output: out_*i[8, 2]
        out = []
        for qi, hi, kbi in zip(out_qi, out_hi, out_kbi): # out_*i[8, 2] total 3 --argmax--> out[8, 3]
            out.append([qi.argmax().data.tolist(), hi.argmax().data.tolist(), kbi.argmax().data.tolist()])
        loss = torch.Tensor([0]).to(self.device) # 原本就在，没必要.to(self.device)
        if self.training:
            loss = F.cross_entropy(out_qi,
                                   torch.Tensor(
                                       utils.tools.tool.in_each(batch, lambda x: x["consistency"][0])).long().to(
                                       self.device)) \
                   + F.cross_entropy(out_hi,
                                     torch.Tensor(
                                         utils.tools.tool.in_each(batch, lambda x: x["consistency"][1])).long().to(
                                         self.device)) \
                   + F.cross_entropy(out_kbi,
                                     torch.Tensor(
                                         utils.tools.tool.in_each(batch, lambda x: x["consistency"][2])).long().to(
                                         self.device))
        return loss, out # loss: 交叉熵损失, out(batch_8*3): list of list[qi_预测值0或1, hi_预测值0或1, kbi_预测值0或1]

    def start(self, inputs):
        # interact_inputs.train_data[list of n dialogue, dialogue is dict of 5key-value]: kb,h,q, last_response, consistency
        train, dev, test, _ = inputs # # train2553, dev319, test318, entities tuple
        if (self.args.model.resume is not None) and (self.args.model.resume != 'None'):
            self.load(self.args.model.resume)
        if not self.args.model.test:
            self.run_train(train, dev, test) # 模型训练和验证 (n epoch) # -> run_train --调用--> n_epoch * (m_run_batches + 1_run_test)) #
        self.run_eval(train, dev, test) # 模型测试 (1 次) # -> run_eval --调用--> run_test

        # 模型训练和验证 (n epoch) # -> run_train --调用--> n_epoch * (m_run_batches + 1_run_test)) #
        # 模型测试 (1 次) # -> run_eval --调用--> run_test
        # 文中代码命名时混乱，验证反倒叫run_test < 测试反倒叫run_eval
        # run_train(训练+验证 * n epoch)返回：logging.info(pprint.pformat(best))，并保留了最优模型
        ## run_batches(training训练并每batch损失自动梯度 * m batches)返回：all_loss / all_size, iteration：单个epoch内各batch的平均损失(每batch一次，loss自动梯度更新参数一次)，和单个epoch的迭代次数320
        ## run_test(validation验证并每epoch更新当前最优)返回：模型评测指标值dict(3*3+1element), 模型预测标签(total_data2553*3)）
        # run_eval(test测试并评价最终性能)返回：logging.info(pprint.pformat(summary))
        # forward返回：loss, out  # loss: 交叉熵损失, out(batch_8*3): list of list[qi_预测值0或1, hi_预测值0或1, kbi_预测值0或1]
        # bert返回：last_hidden_state, pooler_output：last_hidden_state对应的是所有其他的输入字的最后输出, pooler_output对应的是 [CLS] 的输出
        # tokenizer返回：tokenized_data: <class 'dict'> {input_ids: [8[512]] , token_type_ids: [8[512]], attention_mask: [8[512]]} in gpu

    def run_test(self, dataset): # (validation验证并每epoch更新当前最优) #在每轮epoch的模型验证中都被调用一次(验证共n次)，在n轮epoch结束后的模型测试中也被调用一次(测试共1次)
        self.eval()
        all_out = [] # 模型预测标签(total_data2553*3)
        all_size = 0 # 没用到
        all_cos = {} # 没用到
        if self.args.train.compute_cos:
            all_cos["cos_q_kb"] = 0
            all_cos["cos_h_kb"] = 0
            all_cos["cos_q_h"] = 0
        for batch in tqdm(Batch.to_list(dataset, self.args.train.batch)[0: len(dataset)]): # 即便用len(dataset)好像也超出索引范围了？因为batch_num<len(dataset)
        # for batch in tqdm(Batch.to_list(dataset, self.args.train.batch)[0:2]):  # modified-debug 减少调试耗时
            loss, out = self.forward(batch) # return loss, out # loss: 交叉熵损失, out(batch_8*3): list of list[qi_预测值0或1, hi_预测值0或1, kbi_预测值0或1]
            all_out += self.get_pred(out) # [[],[]] -> [[],[]]（self.get_pred()该函数基本没作用)
            all_size += len(batch)
        return self.EvaluateTool.evaluate(all_out, dataset, self.args), all_out 
        # return self.EvaluateTool.evaluate(all_out, dataset[:self.args.train.batch * 2], self.args), all_out # # modified-debug 减少调试耗时
        # run_test返回：模型评测指标值dict(3*3+1element), 模型预测标签(total_data2553*3)

    def run_eval(self, train, dev, test): # (test数据集测试并评价最终性能) #返回 logging.info(pprint.pformat(summary))
        logging.info("Starting evaluation")
        self.eval()
        summary = {}
        ds = {"test": test}
        for set_name, dataset in ds.items():
            tmp_summary, pred = self.run_test(dataset)
            self.DatasetTool.record(pred, dataset, set_name, self.args) # pass # DatasetTool.record函数为空，用于调参？(位于utils.loader.py) # 似乎是保存模型验证的指标结果 
            summary.update({"eval_{}_{}".format(set_name, k): v for k, v in tmp_summary.items()})
        logging.info(pprint.pformat(summary))

    def run_batches(self, dataset, epoch): # (training训练并每batch损失自动梯度 * m batches)
        all_loss = 0 # 每个batch的loss和
        all_size = 0 # 已训练的数据条数
        iteration = 0 # 已训练的batch数
        all_cos = {} # ? # Cosine Similarity（余弦相似度）缺点：余弦相似度的一个主要缺点是没有考虑向量的大小(不同样本权重)，而只考虑它们的方向。
        if self.args.train.compute_cos: # False
            all_cos["cos_q_kb"] = 0
            all_cos["cos_h_kb"] = 0
            all_cos["cos_q_h"] = 0

        # epoch = 10
        # batch8 * n320 = total_train_2533丨Batch.to_list(data, batch_size)功能： [] -> [[],[],...320 batches]
        for batch in tqdm(Batch.to_list(dataset, self.args.train.batch)[0: len(dataset)]):
        # for batch in tqdm(Batch.to_list(dataset, self.args.train.batch)[0: 2]): # modified-debug 减少调试耗时
            # self.forward(batch): return loss, out # loss: 交叉熵损失, out(batch_8*3): list of list[qi_预测值0或1, hi_预测值0或1, kbi_预测值0或1]
            loss, _, = self.forward(batch)
            self.zero_grad()
            loss.backward()
            self.optimizer.step()
            all_loss += loss.item()
            iteration += 1
            all_size += len(batch)
        return all_loss / all_size, iteration # 每条数据平均损失，已训练的batch数

    def run_train(self, train, dev, test): # (训练320batch+验证1 * n epochs) ：----(并没有)返回logging.info(pprint.pformat(best))，并保留了最优模型
        self.set_optimizer()
        iteration = 0 # 记录所有epoch总迭代次数(epoch*batches)，放在summary中
        count = 0 # ?
        for param in self.bert.parameters(): # 无需该操作，默认都设置了requires_grad = True
            param.requires_grad = True
        # epochs = self.args.train.epoch
        for epoch in range(self.args.train.epoch):
        # for epoch in range(2):  # epoch = 10 # modified-debug 减少调试耗时 range(epochs)
            self.train()
            logging.info("Starting training epoch {}".format(epoch))
            summary = {"epoch": epoch, "iteration": iteration}
            loss, iter = self.run_batches(train, epoch)  #--- 模型训练 ---# tqdm*1_train# (training训练并每batch损失执行自动梯度 * m batches)
            # self.run_batches: return all_loss / all_size, iteration # 每条数据平均损失，已训练的batch数
            fitlog.add_loss({"train_loss": loss}, step=epoch)
            summary.update({"loss": loss})
            iteration += iter

            set_name = "dev"
            dataset = dev
            tmp_summary, pred = self.run_test(dataset) #--- 模型验证(还没到模型run_test) ---# tqdm * 1_dev
            # run_test返回：模型评测指标值tmp_summary_dict(3*3+1element), 模型预测标签pred_listoflist(非tensor: total_data2553*3)
            summary.update({"eval_{}_{}".format(set_name, k): v for k, v in tmp_summary.items()})
            fitlog.add_metric({"eval_{}_{}".format(set_name, k): v for k, v in tmp_summary.items()}, step=epoch)
            data = self.recoder.get_error_pred(dataset, pred) #返回data：data存储当前epoch内所有数据项中,非3个标签完全正确的数据项及其预测标签，
            # data结构为：[list of n dict_dialogue, dialogue is dict of 4key-value]:  kb,history,last_response,str(consistency)
            if self.recoder.record([summary['eval_dev_overall_acc']], state_dict=self.state_dict(), data=data):
                # 如果本轮epoch结束时，模型在验证集上的性能有提升
                # record相当于bert.py中的update_best(best, summary, epoch) # 依据当前epoch轮的训练结果summary_dict的overall_acc，判断是否需要更新最优结果best_dict，保存当前最优模型
                count = 0 # count记录模型性能连续未发生提升的epoch数
                self.recoder.print_output() # listoflist:存储当前为止的所有epoch内,每个epoch的error_pred_data_list,到out/out.json文件(显然保存行为会发生覆盖,等效于只保留最后一次save)
                set_name = "test"
                dataset = test
                # # 如果本轮epoch结束时，模型在验证集上的性能有提升，才会在test数据集上执行run_test（才会有多出一个tqdm_bar）,并保留相应的test数据集eval_test_f1_*i评测指标值
                tmp_summary, pred = self.run_test(dataset) # ? 可能是和bert.py中用三种数据集验证一样,为了偷偷达到过拟合效果,挑选一个测试集上更优秀的模型参数
                summary.update({"eval_{}_{}".format(set_name, k): v for k, v in tmp_summary.items()})
                # dev和test数据集的两次run_test紧随的summary.update()并没有覆盖summary词典内的元素，因为新增的变量名称不一样，只发生了新增而没有替换
                fitlog.add_best_metric({"QI F1": summary['eval_test_f1_qi']})
                fitlog.add_best_metric({"HI F1": summary['eval_test_f1_hi']})
                fitlog.add_best_metric({"KBI F1": summary['eval_test_f1_kbi']})
                fitlog.add_best_metric({"Overall": summary['eval_test_overall_acc']})
            else:
                count += 1 # count记录模型性能连续未发生提升的epoch数
                if count == self.args.train.early_stop: # 提前停止（Early Stop）# early_stop=5(这么大,总epoch才10...)
                # 在梯度下降训练的过程中为了避免过拟合,使用验证集(Validation Set)来进行模型选择,测试模型在验证集上是否最优．
                # 验证集也叫作开发集(Development Set), 在每次迭代时把新得到的模型𝑓(𝒙; 𝜃)在验证集上进行测试,并计算错误率
                # 如果(多次迭代过程中发现)在验证集上的错误率不再下降,就停止迭代,这种策略叫提前停止（Early Stop）
                    return
        # 终端输出日志shell-history示例：
        # INFO:root:Loading configure from KBRetriver_DC_INTERACTIVE/KBRetriver_DC_INTERACTIVE.cfg
        # INFO:root:Starting training epoch 0
        # tqdm bar * 3或2(1_train+2或1_eval) # （如果本轮epoch结束时模型在验证集上的性能有提升,才会在test数据集上执行run_test,才会有多出一个tqdm_bar）
        # 中间并没有其它日志，比如保存当前最优模型的日志，打印当前模型性能的日志，打印历史最优模型性能的日志
        # INFO:root:Starting training epoch 1
        # ......
        # INFO:root:Starting evaluation
        # tqdm bar * 1(1_test)

    def load(self, file):
        logging.info("Loading models from {}".format(file))
        state = torch.load(file)
        model_state = state["models"]
        self.load_state_dict(model_state)

    def get_pred(self, out):
        pred = []
        for ele in out:
            pred.append(ele)
        return pred
