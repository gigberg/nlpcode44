import torch
from transformers import BertModel, BertTokenizer

# 从bert.py中拆分出来的两个功能模块：①返回预训练模型PretrainedModelManager，②返回tokenized后的适合于bert模型输入的tensor(gpu),batch.get_info()
class PretrainedModelManager(object):
    def __init__(self, args):
        self.args = args
        self.bert = BertModel.from_pretrained(args.bert.location)
        self.tokenizer = BertTokenizer.from_pretrained(args.bert.location)
        if args.train.gpu:
            self.device = torch.device('cuda')
        else:
            self.device = torch.device('cpu')
        self.pad = self.tokenizer.pad_token # '[PAD]'
        self.sep = self.tokenizer.sep_token # '[SEP]'
        self.cls = self.tokenizer.cls_token # '[CLS]'
        self.pad_id = self.tokenizer.pad_token_id # 0
        self.sep_id = self.tokenizer.sep_token_id # 102
        self.cls_id = self.tokenizer.cls_token_id # 101
        self.special_tokens = ["[SOK]", "[EOK]", "[SOR]", "[EOR]", "[USR]", "[SYS]"]
        # SOK: start of knowledge base
        # EOK: end of knowledge base
        # SOR: start of row # 没用到
        # EOR: end of row # 没用到
        # USR: start of user turn
        # SYS: start of system turn

    def get_info(self, batch, info): # info用于指定bert模型的第一个输入语句类型knowledge_base/query/history，第二个输入语句则始终为last_response
        # in CI-ToD bert.py: 
        # construced_infos = [item['constructed_info???'] for item in batch]
        # constructed_concatenate_dialogue_info'string'(kb+h)："[SOK] "xx xx xx xx ... ; xx ... ;  [EOK]  [USR] yy [SYS]  [USR] yy..."

        # in current CGIM .py: 
        # self.get_info(batch, 'knowledge_base/query/history')
        # one dialogue batch dict_5 ：{knowledge_base:xx, history:xx, query:xx, last_response:xx, consistency:xx}
        infos = [item[info] for item in batch]
        last_responses = [item['last_response'] for item in batch]
        tokenized = self.tokenizer(infos, last_responses, truncation='only_first', padding=True,
                                   return_tensors='pt',
                                   max_length=self.tokenizer.max_model_input_sizes[self.args.bert.location],
                                   return_token_type_ids=True)
        # -----truncation='only_first', padding=True, max_length=512------过长的从头部截断为512长度，较短的填充为batch中最长串的长度(如果最长串发生过截断,自然这里也是512)
        # 实际表现下来，info=kb时常常过长而truncate为512，info=q或h时常常较短而padding到longest(比如某次为q=25,h=82)
        # 可以预料到，不同batch经过tokenized后的向量长度可能不一样，不过这都是不影响bert模型输出层结构的768，因为bert模型内部会将输入token_id填充到默认的模型最大程度512
        tokenized = tokenized.data
        return tokenized['input_ids'].to(self.device), tokenized['token_type_ids'].to(self.device), tokenized[
            'attention_mask'].to(self.device)
        # 返回经过tokenizer()之后得到的数据（符合bert输入参数需求的向量），并且转移到gpu中

