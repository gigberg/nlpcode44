import json
import os

import torch


class Recoder:
    # self.recoder = Recoder("out/", self.args, 1)
    def __init__(self, file_name, args, metric_num, positive_order=True):
        self.args = args
        self.file_name = file_name # filename = "out/"
        self.best_metric = [0 for _ in range(metric_num)] # metric_num = 1
        self.order = positive_order # 多轮epoch中的验证指标中，summary_overall_acc指标值大的更优更适合记录为当前最优
        if not positive_order:
            self.best_metric = [100000 for _ in range(metric_num)]
        self.data = [] # listoflist:存储当前为止(会覆盖,或者说存储所有epoch训练结束时)的所有epoch内,每个epoch的error_pred_data_list,从后文可知被输出到out/out.json文件

    # record相当于bert.py中的update_best(best, summary, epoch) # 依据当前epoch轮的训练结果summary_dict的overall_acc，判断是否需要更新最优结果best_dict，保存当前最优模型----并没有:并删除已保存的多于max_save=2的次优模型
    # run_train(run_batches, run_test, recoder): if self.recoder.record([summary['eval_dev_overall_acc']], state_dict=self.state_dict(), data=data)
    def record(self, now_metric, state_dict=None, data=None): # now_metric=[summary['eval_dev_overall_acc']] 
        if self.compare(now_metric, self.best_metric): # now_metric(单元素list)储存当前epoch轮的训练结果summary_dict的overall_acc(用于比较)
        # self.compare：比较当前summary和best_summary中每个元素指标值，全优返回true(说明要update_best)，否则返回false
            self.best_metric = now_metric # update best to current epoch
            if state_dict is not None:
                self.save(state_dict, 'model') # 保存当前最优模型的状态词典到saved文件夹.pkl文件(只保留一份，后续更优模型会导致同名覆盖，因为名称没有像bert.py一样用epoch区分)
            if data is not None: # data = data存储存储当前epoch内所有数据项中：非3个标签完全正确的数据项及其预测标签，结构为：[list of n dict_dialogue, dialogue is dict of 4key-value]:  kb,history,last_response,str(consistency)
                self.data.append(data) # listoflist:存储当前为止的所有epoch内,每个epoch的error_pred_data_list,从后文可知被输出到out/out.json文件
            return True
        return False

    # run_train(run_batches, run_test, recoder): data = self.recoder.get_error_pred(dataset, pred)
    def get_error_pred(self, ground_data, pred_data): # pred_data：模型预测标签pred_listoflist(非tensor: total_data2553*3)
        data = [] # data存储所有数据项中：非3个标签完全正确的数据项及其预测标签，结构为：[list of n dict_dialogue, dialogue is dict of 4key-value]:  kb,history,last_response,str(consistency)
        # 相较于默认的inputs中train_data结构为：[list of n dict_dialogue, dialogue is dict of 5key-value]:  kb,history,query, last_response, consistency
        for i1, j1 in zip(ground_data, pred_data): # loop 2553
            c = 0
            for m, n in zip(i1['consistency'], j1): # loop 3 (qi/hi/kbi)
                if m == n:
                    c += 1 # 2553*3个标签中的正确个数
            if c != 3: # # 2553*3个标签中的正确个数
                data.append({'knowledge_base': i1['knowledge_base'], 'history': i1['history'],
                             'last_response': i1['last_response'], 'consistency': str(j1)}) # str(consistency)
        return data # data存储所有数据项中：非3个标签完全正确的数据项及其预测标签，结构为：[list of n dict_dialogue, dialogue is dict of 4key-value]:  kb,history,last_response,str(consistency)

    def print_output(self): # save self.data as json to "out/out.json"
        # fo = open(self.file_name + "out.txt", "w") # filename = "out/"
        fo = open(self.file_name + "out.json", "w")
        fo.write(self.print_method(self.data)) # self.print_method: return self.data as json
        fo.close()

    def print_method(self, s): # return self.data as json
        return str(json.dumps(s))

    def compare(self, now, best): # 比较当前summary和best_summary中每个元素指标值，全优返回true，否则返回false
        for i, j in zip(now, best):
            if self.order and i <= j: # self.order = positive_order = True 指标值大的更优
                return False
            if not self.order and i >= j:
                return False
        return True

    def save(self, state_dict, name): # 保存当前最优模型的状态词典到output文件夹.pkl文件, 后续的更优模型会直接以相同文件名覆盖保存，(并没有)删除已保存的多于max_save=2的次优模型
        file = "{}/{}.pkl".format(self.args.dir.output, name) # self.args.dir.output = "saved/"
        if not os.path.exists(self.args.dir.output):
            os.makedirs(self.args.dir.output)
        state = {"models": state_dict}
        torch.save(state, file)


if __name__ == '__main__':
    r = Recoder("../../out/", None, 1)
    r.record([2])
